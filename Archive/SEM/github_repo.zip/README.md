# readAbaqusInputFile
This repository is for reading abaqus inp file purpose in Matlab software plateform
It is useful for reading a single inp file with nodes and a single type of element
Examples can be seen in the demo.m file, anyone can use it to import elements, nodes and element type.
% example
% filename = 'exam.inp';
% [nodes， elements, elementType] = readinp(filename);
Any help can be asked please contact Ji Wan
Ji Wan contributes all the code lines and will maintain them.
