close all
clear
clc

Mesh.ElOrder = 5;
Mesh.Order = 4;
Mesh.Nel = [40 20];
dim = [0 10; 0 20];

BB1=[2 3; 0 4];
BB2=[2 3; 10 20];

Mesh = Mesher(Mesh,dim);
% remove elements
[~,ElList] = BB(Mesh,BB1);
Mesh.Connectivity(ElList,:)= [];
[~,ElList] = BB(Mesh,BB2);
Mesh.Connectivity(ElList,:)= [];

if 1
    figure;
    hold on;
    axis equal;

    % Plot elements
    for el = 1:size(Mesh.Connectivity,1)
        nodeIDs = Mesh.Connectivity(el,2:5);
        x_coords = Mesh.Nodes(nodeIDs,1);
        y_coords = Mesh.Nodes(nodeIDs,2);

        % Close the quadrilateral
        x_coords(5) = x_coords(1);
        y_coords(5) = y_coords(1);

        plot(x_coords, y_coords, 'b-');
    end

end

Mesh = MakeSEMMesh(Mesh);

% Plot nodes
plot(Mesh.Nodes(:,1), Mesh.Nodes(:,2), 'ro', 'MarkerFaceColor', 'r');


kappa=1;
rho = 1;
[M,K] = makeMK(Mesh,kappa,rho);